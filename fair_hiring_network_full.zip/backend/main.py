
from fastapi import FastAPI, HTTPException, Depends, Header
from pydantic import BaseModel
from typing import List, Dict, Optional
from auth import hash_password, verify_password, generate_token, decode_token

app = FastAPI()

users = []
logged_in_tokens = []
candidates = []
jobs = []

class User(BaseModel):
    email: str
    password_hash: str
    role: str

class LoginInput(BaseModel):
    email: str
    password: str

class CandidateCreate(BaseModel):
    name: str
    email: str
    skills: Dict[str, int]

class Candidate(BaseModel):
    id: int
    name: str
    email: str
    skills: Dict[str, int]

class JobCreate(BaseModel):
    title: str
    required_skills: Dict[str, int]

class Job(BaseModel):
    id: int
    title: str
    required_skills: Dict[str, int]

async def require_auth(authorization: Optional[str] = Header(None)):
    if authorization is None:
        raise HTTPException(status_code=401, detail="Missing Token")
    token = authorization.replace("Bearer ", "").strip()

    if token not in logged_in_tokens:
        raise HTTPException(status_code=401, detail="Invalid Token")

    decoded = decode_token(token)
    return decoded

@app.post("/signup")
def signup(email: str, password: str, role: str):
    for user in users:
        if user["email"] == email:
            raise HTTPException(status_code=400, detail="User already exists")

    users.append({
        "email": email,
        "password_hash": hash_password(password),
        "role": role
    })
    return {"status": "User Created"}

@app.post("/login")
def login(data: LoginInput):
    for user in users:
        if user["email"] == data.email and verify_password(data.password, user["password_hash"]):
            token = generate_token(user["email"], user["role"])
            logged_in_tokens.append(token)
            return {"token": token, "role": user["role"]}
    raise HTTPException(status_code=401, detail="Invalid Credentials")

@app.post("/candidates")
def create_candidate(data: CandidateCreate, decoded=Depends(require_auth)):
    new_id = len(candidates) + 1
    candidates.append({
        "id": new_id,
        "name": data.name,
        "email": data.email,
        "skills": data.skills
    })
    return {"status": "Candidate Stored", "id": new_id}

@app.post("/jobs")
def create_job(data: JobCreate, decoded=Depends(require_auth)):
    new_id = len(jobs) + 1
    jobs.append({
        "id": new_id,
        "title": data.title,
        "required_skills": data.required_skills
    })
    return {"status": "Job Stored", "id": new_id}

@app.get("/jobs/{job_id}/matches")
def match_candidates(job_id: int, decoded=Depends(require_auth)):
    job = next((j for j in jobs if j["id"] == job_id), None)
    if not job:
        raise HTTPException(404, "Job not found")

    result = []
    for cand in candidates:
        matching = []
        for skill, req in job["required_skills"].items():
            matching.append(min(cand["skills"].get(skill, 0), req) / req)
        score = sum(matching) / len(matching)
        result.append({"candidate": cand["name"], "score": score})

    result.sort(key=lambda x: x["score"], reverse=True)
    return result
